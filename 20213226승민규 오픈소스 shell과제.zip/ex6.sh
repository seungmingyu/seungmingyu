free | awk '/Mem:/ {print "Total Memory: " $2 "\nUsed Memory: " $3}'

