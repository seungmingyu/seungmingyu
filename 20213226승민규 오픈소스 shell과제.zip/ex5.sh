ps -ef | grep ssh | grep -v grep

